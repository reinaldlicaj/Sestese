<?php
session_start();

$db = mysqli_connect('localhost', 'root', 'admin', 'registroDB');
$username = "";
$idu="";
$errors = array();



if (isset($_POST['login_user'])) {
  $username = mysqli_real_escape_string($db, $_POST['username']);
  $password = mysqli_real_escape_string($db, $_POST['password']);


  if (empty($password)||empty($username)) {
  	array_push($errors, "Campi vuoti!!!");
  }




  if (count($errors) == 0) {


  	$query = "SELECT * FROM users WHERE username='$username' AND password='$password'";
  	$results = mysqli_query($db, $query);
    	if (mysqli_num_rows($results) == 1){


        $_SESSION['username'] = $username;
        $_SESSION['success'] = "You are now logged in";
        header('location: inventory.php');
      }
else {

  		array_push($errors, "Contattare la sede prima possibile. Grazie.");
  	}
  }
}

?>
<?php
$connect = mysqli_connect("localhost", "root", "admin", "registroDB");
$query1 = "SELECT * FROM users ORDER BY id ASC";
$result = mysqli_query($connect, $query1);
?>
