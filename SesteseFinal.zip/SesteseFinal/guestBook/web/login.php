<?php include('server.php') ?>
<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>GuestBook-Login</title>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
   <link href="ficon.ico" rel="icon" type="image/x-icon" />

  <link rel='stylesheet prefetch' href='https://fonts.googleapis.com/css?family=Open+Sans:600'>
      <link rel="stylesheet" href="./css/style1.css">
      <link rel="stylesheet" href="./css/style2.css">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="stylesheet" href="css/bootstrap.min.css">
      <link rel="stylesheet" href="css/bootstrap-theme.min.css">
      <link rel="stylesheet" href="css/loader.css">
    <link rel="stylesheet" href="css/jquery.dataTables.min.css">
      <link rel="stylesheet" href="css/dataTables.bootstrap.min.css">
      <link rel="stylesheet" href="css/responsive.bootstrap.min.css">
</head>
<body>
  <div class="login-wrap">

  <div class="login-html">

   
  
    <div class="login-form">
    <!--/* LOGO */-->
     <div class="move1" align="center"> <img src="logotransparent.png" alt="appLogo"></div>
     
     
      <form class="sign-in-htm" action="login.php" method="POST">
           


        <div class="group">
          <label for="user" class="label">Nome utente</label>
          <input id="username" name="username" type="text" class="input">
        </div>
        <div class="group">
          <label for="pass" class="label">Password</label>
          <input id="password" name="password" type="password" class="input" data-type="password">
        </div>
        <div class="group">
          <input id="check" type="checkbox" class="check" checked>
          <label for="check"><span class="icon"></span> Mantienimi connesso</label>
        </div>
        <div class="group">
          <input type="submit" class="button" value="Accedere"  name="login_user">
        </div>
        <div class="error">
        <?php include('errors.php'); ?>
      </div>
        <div class="hr"></div>
        <div class="foot-lnk">
        BENVENUTO
        </div>
     
      </form>
      
      

    </div>
  </div>
</div>


</body>
</html>
