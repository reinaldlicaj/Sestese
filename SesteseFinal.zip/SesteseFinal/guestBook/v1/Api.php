<?php

	//getting the dboperation class
	require_once '../includes/DbOperation.php';

				date_default_timezone_set("Europe/Rome");
                 $data = date('Y-m-d H:i:s');


ini_set('display_errors', 1);

	//an array to display response
	$response = array();

	//if it is an api call
	//that means a get parameter named api call is set in the URL
	//and with this parameter we are concluding that it is an api call
	if(isset($_GET['apicall'])){

		switch($_GET['apicall']){

			//the CREATE operation
////////////////////////////////////////  FORNITORE /////////////////////////////
			case 'addFornitor':
					date_default_timezone_set("Europe/Rome");
                 $data = date('Y-m-d H:i:s');
		$presente=1;
				$tipo='F';
				
				//creating a new dboperation object
				$db = new DbOperation();

				//creating a new record in the database
				$result = $db->addFornitor(
					
					$_POST['nome'],
					$_POST['cognome'],
					$_POST['email'],
					$_POST['referente'],
					$_POST['fornitore'],
					$_POST['ruolo'],			
					$_POST['motivo'],
					$_POST['firma'],
					$_POST['code'],
					$_POST['qrcode'],
					$data,
					$presente,
					$tipo
					

				);


				//if the record is created adding success to response
				if($result){
					//record is created means there is no error
					$response['error'] = false;

					//in message we have a success message
					$response['message'] = ' ';

					//and we are getting all the heroes from the database in the response
					$response['fornitores'] = $db->getFornitores();
				}else{

					//if record is not added that means there is an error
					$response['error'] = true;

					//and we have the error message
					$response['message'] = 'Errore';
				}

			break;

			//the READ operation
			//if the call is getheroes
			case 'getFornitores':
				$db = new DbOperation();
				$response['error'] = false;
				$response['message'] = '';
				$response['fornitores'] = $db->getFornitores();
			break;
				
					//the READ operation
			//if the call is getheroes
			case 'getCodeFornitores':
				$db = new DbOperation();
				$response['error'] = false;
				$response['message'] = '';
				$response['fornitores'] = $db->getCodeFornitores();
			break;


	


///////////////////////////  REFERENTS  /////////////////////////////////////////////////////////


				case 'createReferente':
				//first check the parameters required for this request are available or not
				//isTheseParametersAvailable(array('nomeR', 'cognomeR', 'emailR', 'ruoloR'));
				//creating a new dboperation object
				$db = new DbOperation();
				//creating a new record in the database
				$result = $db->createReferente(
					$_POST['nomeR'],
					$_POST['cognomeR'],
					$_POST['emailR'],
          	        $_POST['telefonoR'],
					$_POST['ruoloR']
				);

				//if the record is created adding success to response
				if($result){
					//record is created means there is no error
					$response['error'] = false;

					//in message we have a success message
					$response['message'] = '';

					//and we are getting all the heroes from the database in the response
					$response['referents'] = $db->getReferents();
				}else{

					//if record is not added that means there is an error
					$response['error'] = true;

					//and we have the error message
					$response['message'] = '';
				}

			break;

				case 'getReferents':
				$db = new DbOperation();
				$response['error'] = false;
				$response['message'] = '';
				$response['referents'] = $db->getReferents();
			break;


////////////////////////////////////  VISITORS   ////////////////////////////////////////////////////
				case 'createVisitor':
				//first check the parameters required for this request are available or not
				//isTheseParametersAvailable(array('nomeR', 'cognomeR', 'emailR', 'ruoloR'));
					date_default_timezone_set("Europe/Rome");
                 $data = date('Y-m-d H:i:s');
		          $presente=1;
				$tipo='V';
			

				//creating a new dboperation object
				$db = new DbOperation();
				//creating a new record in the database
				$result = $db->createVisitor(
					$_POST['nome'],
					$_POST['cognome'],
					$_POST['email'],
					$_POST['referente'],
					$_POST['azienda'],
					$_POST['ruolo'],				 
					$_POST['firma'],
					$_POST['code'],
					$_POST['qrcode'],
					$data,
					$presente,
					$tipo
					
				);


				//if the record is created adding success to response
				if($result){
					//record is created means there is no error
					$response['error'] = false;
					//in message we have a success message
					$response['message'] = '';
					//and we are getting all the heroes from the database in the response
					$response['visitors'] = $db->getVisitors();
				}else{
					//if record is not added that means there is an error
					$response['error'] = true;
					//and we have the error message
					$response['message'] = 'Errore';
				}
			break;
				case 'getVisitors':
				$db = new DbOperation();
				$response['error'] = false;
				$response['message'] = '';
				$response['visitors'] = $db->getVisitors();
			break;
				
					case 'getCodeVisitors':
				$db = new DbOperation();
				$response['error'] = false;
				$response['message'] = '';
				$response['visitors'] = $db->getCodeVisitors();
			break;
		}

	}else{
		//if it is not api call
		//pushing appropriate values to response array
		$response['error'] = true;
		$response['message'] = 'Chiamata API non valida';
	}

	//displaying the response in json structure
	echo json_encode($response);
