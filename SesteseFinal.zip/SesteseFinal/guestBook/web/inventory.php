<?php
include 'include/controller.php';
$session_username = $_SESSION['username'];

$install="0";
if(empty($_SESSION['username'])){
    header("location:login.php");
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Guest Book</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Type" content="image/jpeg" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <link href="ficon.ico" rel="icon" type="image/x-icon" />
    
    <script src="js/jquery-1.12.4.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.dataTables.min.js"></script>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-theme.min.css">
    <link rel="stylesheet" href="css/loader.css">
    <link rel="stylesheet" href="./css/style2.css">

    <link rel="stylesheet" type="text/css" href="dashboard/vendor/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="css/dataTables.bootstrap.min.css">
    <link rel="stylesheet" href="css/responsive.bootstrap.min.css">
    <script>
        $(document).ready(function() {
                $('#example').DataTable({});
            });

        </script>



    <script type="text/javascript">

    $(document).on('hidden.bs.modal', function (e) {
           var target = $(e.target);
           target.removeData('bs.modal')

       });
    </script>
</head>

<body onload="myFunction()" style="margin:0;">
    <div class="tesss">
  <div class="smth">

    <div class="container">

        <div class="dropdown">
            <button class="btn btn-success dropdown-toggle btn-md" type="button" data-toggle="dropdown" style="font-size:20px"><span class='glyphicon glyphicon-user' aria-hidden='true'></span>
                <?php echo $session_username ; ?> <span class="caret"></span></button>
            <ul class="dropdown-menu">
                <li ><a href="#logout" data-toggle="modal" style="font-size:20px"><span class='glyphicon glyphicon-log-out' aria-hidden='true' style="font-size:20px"></span>Disconnettersi</a></li>
              <!--  <li><a href="#changepass" data-toggle="modal"><span class='glyphicon glyphicon-edit' aria-hidden='true'></span> Change Password</a></li>-->
            </ul>
              <!--
            <a href="#add" data-toggle="modal">
                <button type='button' class='btn btn-success btn-sm'><span class='glyphicon glyphicon-plus' aria-hidden='true'></span> Job</button>
            </a>
          -->

                              <a href="#addforni" data-toggle="modal">
                                  <button type='button' class='btn btn-warning btn-lg' style="font-size:20px" ><span class='glyphicon glyphicon-plus' aria-hidden='true'style="font-size:20px" ></span>REFERENT</button>
                              </a>
        </div>
        <br>
        <table id="example" class="display nowrap" cellspacing="0" width="100%">
            <thead>
                <tr  style="color:green">

                    <th style="font-size:20px">Nome</th>
                    <th style="font-size:19px">Data&Ora Entrata</th>
                    <th style="font-size:19px">Data&Ora Uscita</th>
                    <th style="font-size:19px">Codice</th>
                    <th style="font-size:19px">Referente</th>
                    <th style="font-size:19px">Presente</th>
                    <th style="font-size:19px"></th>

                </tr>
            </thead>


            <tbody>



                <?php
                    $sql = "SELECT *  FROM visitatori";
                    $result = $conn->query($sql);
                    if ($result->num_rows > 0) {
                        // output data of each row
                        while($row = $result->fetch_assoc()) {
                          $id= $row['id'];
                          $nomeV= $row['nome'];
                           $cognomeV= $row['cognome'];
                          $doev= $row['dataOraEntrata'];
                          $douv = $row['dataOraUscita'];
                          $codev = $row['code'];
                          $referentev=$row['referente'];
                          $aziendav=$row['azienda'];
						 $fornitore=$row['fornitore'];
                          $ruolov=$row['ruolo'];
							$motivo=$row['motivo'];
                          $emailv=$row['email'];
                          $imagesv=$row['firma'];
							$tipo=$row['tipo'];
							
                          $qrcodev=$row['qrcode'];
                          $presente=$row['presente'];

                    ?>
                <tr>
                    <td style="font-size:19px">
                        <?php echo $nomeV,' ',$cognomeV; ?>
                    </td>
                    <td style="font-size:19px">
                        <?php         if($doev!=null)
                              {
                                $doev = date("d/m/Y H:i:s a", strtotime($doev));
                              }

                                 echo $doev; ?>
                    </td>

                    <td style="font-size:19px">
                        <?php      if($douv!=null&&$presente!=1)
                              {
                                $douv = date("d/m/Y H:i:s a", strtotime($douv));
                                echo $douv;
                              }

                                   ?>
                    </td>

                    <td style="font-size:19px">
                        <?php echo $codev; ?>
                    </td>
                    <td style="font-size:19px">
                        <?php echo $referentev; ?>
                    </td>
                    <td style="font-size:19px">
                        <?php if($presente==1){
                          $presente='Si';
                        }
                        else{
                          $presente='No';
                        }
                        echo  $presente; ?>
                    </td>
                    <td>   
                        <a href="#edit<?php echo $id;?>" data-toggle="modal">
                            <button type='button' class='btn btn-success btn-lg' style="font-size:20px" ><span class='glyphicon glyphicon-zoom-in' aria-hidden='true'style="font-size:20px" ></span></button>
                        </a>
                   </td>
      <!--Edit Item Modal   Dettagli di un visitatore  -->
                    <div id="edit<?php echo $id; ?>" class="modal fade" role="dialog">
                        <form method="post" action="pdf.php" class="form-horizontal" role="form">
                            <div class="modal-dialog modal-lg">
                                <!-- Modal content-->
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                        <h2 class="modal-title"  style="color:green" >Dettagli</h2>
                                    </div>
                                    <div class="modal-body">
                                                <input type="hidden" name="edit_item_id" value="<?php echo $id; ?>">
                                                <div class="form-group">
                                                      <label class="control-label col-sm-2" for="nclie" style="font-size:20px"> Nome:</label>
                                                      <div class="col-sm-4">
                                                          <input type="text" class="form-control" id="nclie" name="nclie" value="<?php echo $nomeV,' ',$cognomeV; ?>" placeholder="Nome"  readonly style="font-size:20px"> </div>
                                                            <label class="control-label col-sm-2" for="ema" style="font-size:20px">Email:</label>

                                                          
                                                          <div class="col-sm-4">
                                                          
                                                               <input type="text" class="form-control" id="ema" name="ema" value="<?php echo $emailv; ?>" placeholder="" readonly style="font-size:20px">
                                                            
                                                             </div>
                                                </div>
 <!--///////////////////////// ///////////////////////// -->   

        										<div class="form-group">
                              <label class="control-label col-sm-2" for="ruo" style="font-size:20px">Ruolo:</label>
                              <div class="col-sm-4">
                                  <input type="text" class="form-control" id="ruo" name="ruo" value="<?php echo $ruolov; ?>"  placeholder=""  readonly style="font-size:20px"> </div>
                                             <label class="control-label col-sm-2" for="azie" style="font-size:20px">Referente:</label>
                                                  
                                                    <div class="col-sm-4">
                                                        <input type="text"  class="form-control" id="refe" name="refe" value="<?php echo $referentev; ?>" placeholder=""  readonly style="font-size:20px">
                                                       </div>
                                                </div>
                                                
                                                 <!--///////////////////////// ///////////////////////// -->   
                                                
        										<div class="form-group">
                              <label class="control-label col-sm-2" for="ruo" style="font-size:20px">Fornitore:</label>
                              <div class="col-sm-4">
                                  <input type="text" class="form-control" id="fornit" name="fornit" value="<?php echo $fornitore; ?>"  placeholder=""  readonly style="font-size:20px"> </div>
                                             <label class="control-label col-sm-2" for="azie" style="font-size:20px">Azienda:</label>
                                                  
                                                    <div class="col-sm-4">
                                                        <input type="text"  class="form-control" id="azie" name="azie" value="<?php echo $aziendav; ?>" placeholder=""  readonly style="font-size:20px">
                                                       </div>
                                                </div>
                                             <!--///////////////////////// ///////////////////////// -->    
                                                
                                                				<div class="form-group">
                              <label class="control-label col-sm-2" for="ruo" style="font-size:20px">Codice:</label>
                              <div class="col-sm-4">
                                  <input type="text" class="form-control" id="code" name="code" value="<?php echo $codev; ?>"  placeholder=""  readonly style="font-size:20px"> </div>
                                             <label class="control-label col-sm-2" for="azie" style="font-size:20px">Tipo:</label>  
                                                    <div class="col-sm-4">
                                                        <input type="text"  class="form-control" id="tipo" name="tipo" value="<?php echo $tipo; ?>" placeholder=""  readonly style="font-size:20px">
                                                       </div>
                                                </div>
                                                
                                                
                                                     <!--///////////////////////// Data e Ora///////////////////////// -->    
                                               
                                                				<div class="form-group">
                              <label class="control-label col-sm-2" for="ruo" style="font-size:20px">Entrata:</label>
                              <div class="col-sm-4">
                                  <input type="text" class="form-control" id="doe" name="doe" value="<?php echo $doev; ?>"  placeholder=""  readonly style="font-size:20px"> </div>
                                             <label class="control-label col-sm-2" for="azie" style="font-size:20px">Uscita:</label>
                                                  
                                                    <div class="col-sm-4">
                                                        <input type="text"  class="form-control" id="dou" name="dou" value="<?php echo $douv; ?>" placeholder=""  readonly style="font-size:20px">
                                                       </div>
                                                </div>
                                                 <!--///////////////////////// ///////////////////////// -->   
                                           <div class="form-group">
                              <label class="control-label col-sm-2" for="ruo" style="font-size:20px">Motivo:</label>
                              <div class="col-lg-10">
                                  <input type="text" class="form-control" id="code" name="code" value="<?php echo $motivo ; ?>"  placeholder=""  readonly style="font-size:20px"> </div>
                                            
                                                </div>
                                                
                                                
                                                
<!--///////////////////////// /////////////////// Firma e QR code/////*/ -->            
                               <div class="form-group">
                              <label class="control-label col-sm-2" for="ruo" style="font-size:20px">Firma:</label>
                              <div class="col-md-4">
                                  <?php   echo '<img src="data:image;base64,'.$imagesv.'" height="200"  width="250">';?>  
                                                     </div>
                                                     
                                                     
                                                    <label class="control-label col-sm-2" for="ema" style="font-size:20px">Codice QR :</label>
                                                    <div class="col-md-4">
                                                    <?php  
						echo	'<img src="data:image/jpeg;base64,'.$qrcodev.'"  height="200"  width="250"/>'; ?>						
	
                                                 </div>
                                                </div>

<!--/* //////////////////////////*/-->


                                            </div>
                                    <div class="modal-footer">
                                  <!--    <button type="submit" class="btn btn-warning" name="update_item"><span class="glyphicon glyphicon-edit"></span> Salva</button>-->
                                        <button type="button" class="btn btn-danger btn-lg" data-dismiss="modal" style="font-size:20px" ><span class="glyphicon glyphicon-remove-circle" style="font-size:20px" ></span> Chiudi</button>

                                        <!--<button type="submit" class="btn btn-danger" name="closepk1"><span class="glyphicon glyphicon-off"></span> Chiudi chiamata</button>-->
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>



                    <!--Add Fornitore -->
                    <div id="addforni" class="modal fade" role="dialog">
                        <form method="post" class="form-horizontal" role="form">
                            <div class="modal-dialog modal-lg">
                                <!-- Modal content-->
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                        <h2 class="modal-title" style="color:green">Inserisci Referente</h2>
                                    </div>
                                    <div class="modal-body">
                              <input type="hidden" name="riappid" value="<?php echo $id; ?>">
                              <div class="form-group">
                                <label class="control-label col-sm-2" for="nome" style="font-size:20px" >Nome:</label>
                                <div class="col-sm-4">
                                    <input type="text"  class="form-control" id="nome" name="nome"  placeholder="Nome"  style="font-size:20px" required > </div>
                              <label class="control-label col-sm-2" for="cognome" style="font-size:20px">Cognome:</label>
                                  <div class="col-sm-4">
                                      <input type="text"  class="form-control" id="cognome" name="cognome"  placeholder="Cognome"  style="font-size:20px"  required> </div>
                              </div>
                              <div class="form-group">
                                <label class="control-label col-sm-2" for="email" style="font-size:20px">Email:</label>
                                <div class="col-sm-4">
                                    <input type="text"  class="form-control" id="email" name="email"  placeholder="Email"  style="font-size:20px" required> </div>
                              <label class="control-label col-sm-2" for="telefono" style="font-size:20px">Telefono:</label>
                                  <div class="col-sm-4">
                                      <input type="text" class="form-control" id="telefono" name="telefono"  placeholder="Telefono"  style="font-size:20px" required> </div>
                              </div>
                              <div class="form-group">
                                <label class="control-label col-sm-2" for="ruolo" style="font-size:20px">Ruolo:</label>
                                <div class="col-sm-4">
                                    <input type="text"  class="form-control" id="ruolo" name="ruolo"  placeholder="Ruolo"  style="font-size:20px" required > </div>
                              </div>


                                            </div>
                                    <div class="modal-footer">
                                        <button type="submit" class="btn btn-warning btn-lg" name="addfornitore" style="font-size:20px" ><span class="glyphicon glyphicon-edit" style="font-size:20px" ></span> Salva</button>
                                        <button type="button" class="btn btn-danger btn-lg" data-dismiss="modal"  style="font-size:20px" ><span class="glyphicon glyphicon-remove-circle" style="font-size:20px" ></span> Annulla</button>

                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>

                    <!--Delete Modal
                    <div id="delete<?php echo $id; ?>" class="modal fade" role="dialog">
                        <div class="modal-dialog">
                            <form method="post">

                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                        <h4 class="modal-title">Delete</h4>
                                    </div>
                                    <div class="modal-body">
                                        <input type="hidden" name="delete_id" value="<?php echo $id; ?>">
                                        <div class="alert alert-danger">Are you Sure you want Delete <strong>
                                                <?php echo $serial; ?>?</strong> </div>
                                        <div class="modal-footer">
                                            <button type="submit" name="delete" class="btn btn-danger"><span class="glyphicon glyphicon-trash"></span> YES</button>
                                            <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove-circle"></span> NO</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    -->
                </tr>
                <?php
                        }
           
       

                        //addforni
                        if(isset($_POST['addfornitore'])){
                          $riappid = $_POST['riappid'];
                          $nome =  $_POST['nome'];
                          $cognome =  $_POST['cognome'];
                          $email =  $_POST['email'];
                          $telefono =  $_POST['telefono'];
                          $ruolo =  $_POST['ruolo'];
                          $sql = "INSERT INTO referenti (nomeR,cognomeR,emailR,telefonoR,ruoloR)VALUES ('$nome','$cognome','$email','$telefono','$ruolo')";
                          if ($conn->query($sql) === TRUE) {
                              echo '<script>window.location.href="inventory.php"</script>';
                          } else {
                              echo "Error updating record: " . $conn->error;
                          }


                        }


                    }
?>

            </tbody>
        </table>
    </div>
  </div>
    <!--Logout Modal -->
    <div id="logout" class="modal fade" role="dialog">
        <div class="modal-dialog modal-md">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h3 class="modal-title">Disconnettersi</h3>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="delete_id" value="<?php echo $id; ?>" style="font-size:20px">
                    <div class="alert alert-success" style="font-size:20px">Sei sicuro di voler uscire
                        <strong>
                            <?php echo $_SESSION['username']; ?>?
                        </strong>
                    </div>
                    <div class="modal-footer">
                        <a href="logout.php">
                            <button type="button" class="btn btn-danger btn-lg" style="font-size:20px">SI </button>
                        </a>
                        <button type="button" class="btn btn-default btn-lg" data-dismiss="modal" style="font-size:20px">No</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
  </div>
</body>


</html>
