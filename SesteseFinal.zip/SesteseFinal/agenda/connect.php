
<?php
//Dichiarazioni variabili per la connessione al database
$host = 'localhost';
$user = 'root';
$password = 'admin';
$database = 'agenda';
// Connessione al database server
$conn= mysqli_connect($host, $user, $password, $database) or die ("Impossibille collegare con Server ");
// Selezione del database
echo ""

?>
