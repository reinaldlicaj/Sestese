<?php
include  'Connections.php';
 $sql2="SELECT nome ,cognome  FROM visitatori
 WHERE presente='1'";

	$r2 = mysqli_query($conn,$sql2);
$result = array();
while($row = mysqli_fetch_array($r2)){
 array_push($result,array(
	
	   'nome'=>$row['nome'],
	 'cognome'=>$row['cognome']	
    ));
	
}
	echo json_encode(array('result'=>$result));

mysqli_close($conn);



?>