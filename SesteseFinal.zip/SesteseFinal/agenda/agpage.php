<!DOCTYPE html>
<html lang="en">
<head>
  <title>Test</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>

  <link href="css/addons/datatables.min.css" rel="stylesheet">
  <script type="text/javascript" src="js/addons/datatables.min.js"></script>

  <script src="https://kit.fontawesome.com/a076d05399.js"></script>
   <link href="Style.css" rel="stylesheet">

<link href="css/bootstrap-datetimepicker.min.css" rel="stylesheet">
<script src="js/bootstrap-datetimepicker.min.js"></script>
 <link href="lawyer.ico" rel="icon" type="image/x-icon" />

  <style>
    /* Set height of the grid so .sidenav can be 100% (adjust if needed) */

  </style>
  <script>
$(document).ready(function () {
$('#dtBasicExample').DataTable();
$('.dataTables_length').addClass('bs-select');
});
</script>
	<script type="text/javascript">
$("#datepiker").datepicker({
    format: 'yyyy-mm-dd '
});
		$('.alert').alert();

		 $("#edit").draggable({
      handle: ".modal-header"
  });
</script>
</head>
<body>

<div class="container-fluid">
  <div class="row content">
    <div class="col-sm-3 sidenav" >
    <a class="navbar-brand" href="#">
          <img src="avLogo.png" alt="">
        </a>

      <h4>Segreteria Avvocati</h4><br/>
      <ul class="nav nav-pills nav-stacked">
        <li><a href="index.php"><i class="fas fa-home "></i> HOME</a></li>
        <li  class="active"><a href="agpage.php"><i class="fas fa-book" ></i>  AGENDA</a></li>
         <li  ><a href="avocati.php"><i class="fas fa-user-tag"></i>  AVVOCATI</a></li>

      </ul><br>

    </div>



    <div class="col-sm-9">
   <!-- /////////////////////////////////////////////////////////////////pagina che si scambia-->


     <div class="jumbotron jumbotron-fluid">
  <div class="container">
   <h1 >Lista  comunicazioni da clienti </h1>
		 </div>
	</div>


     <div class="container">

       <div class="row">
          <form method="post"  action="agpage.php?go" id="searchForm" class="search">

            <div class="col-md-3">
          <div class="form-group" id='datepicker'>
    				<label > From</label>
                  <input  type="date"  name="dateFrom" placeholder="From..." class="form-control" id="datePickerId">
                  <script > datePickerId.max = new Date().toISOString().split("T")[0];</script>

                </div>
           </div>

             <div class="col-md-3">
            	 <div class="form-group" id='datepicker'>
               			<label > To</label>
                 		 <input  type="date" name="dateTo" placeholder="To..." class="form-control" id="datePickerId2">
                 		   <script > datePickerId2.max = new Date().toISOString().split("T")[0];</script>
  			        </div>
            </div>


            <div class="col-md-3">
                <div class="form-group"  >
                   <label>  Clienti del:</label>
                  <input  type="text" name="avvocato" placeholder="nome avvocato" class="form-control" id="advName">

                </div>
            </div>

            <div class="col-md-3">
                <div class="form-group">
					<label> </label></br>
                    <button type="submit" name="searchBtn" class="btn  btn-primary">
     						 <i class="glyphicon glyphicon-search"></i>
   						 </button>
                </div>
            </div>
          </form>
        </div>
		</br>



       <div class="table-responsive">

     <table id="dtBasicExample" class="table  table-bordered table-hover" cellspacing="0"
  width="100%">
  <thead>
    <tr>
      <th class="th-sm">Nome Del Cliente
       <span class="glyphicon glyphicon-sort"></span>
      </th>
      <th class="th-sm">Numero Telefono

      </th>
      <th class="th-sm">Data di contatto
       <span class="glyphicon glyphicon-sort"></span>
      </th>
      <th class="th-sm">Email

      </th>
      <th class="th-sm">Note

      </th>
      <th class="th-sm">Avvocato Riferimento
       <span class="glyphicon glyphicon-sort"></span>
      </th>
      <th class="th-sm">Edit

      </th>
    </tr>
  </thead>
  <tbody>


     <?php
		include("connect.php");
	 if (isset($_POST['searchBtn'])){
		 $dateFrom= $_POST['dateFrom'];
		 $dateTo= $_POST['dateTo'];
		  $avvocato= $_POST['avvocato'];
		 $sql="select * from agenda WHERE dat BETWEEN '$dateFrom' AND  '$dateTo'  AND LOWER(avocato) LIKE LOWER('%$avvocato%')";

		 $result  = filterTable($sql);
		echo ' <strong>	Resultati da: '.$dateFrom.'      a: '.$dateTo.'</strong>';
	 }
	  else{
		$sql= "select * from agenda";
		  $result  = filterTable($sql);
	  }

	  function filterTable($sql)
{
 $conn= mysqli_connect('localhost', 'root', 'admin', 'agenda') or die ("Impossibille collegare con Server ");
    $filter_Result = mysqli_query($conn, $sql) or die(mysqli_error($conn));
    return $filter_Result;
}



		$result= mysqli_query($conn, $sql);
		while($row=mysqli_fetch_array($result)){
    $dat=$row['dat'];
    $newDate = date("d-m-Y", strtotime($dat));

			echo'
			  <tr>
      <td class="td1">'.$row['nome'].'</td>
      <td>'.$row['tel'].'</td>
      <td>'. $newDate.' </td>
      <td>'.$row['email'].'</td>
      <td>'.$row['note'].'</td>
      <td>'.$row['avocato'].' </td>';

	  ?>


	   <td><a href="#edit<?php echo $row['id'];?>" data-toggle="modal"  >
				<button type="button" class="btn btn-md"  >
						<span class="glyphicon glyphicon-pencil" style="font-size: 18px;font-weight: bolder;" aria-hidden="true">
	   					</span>
	   			</button>
        </a></td>
    </tr>

     <!--   Edit Modal  -->
      <div id="edit<?php echo $row['id'] ; ?>" class="modal fade"   role="dialog">

                            <div class="modal-dialog modal-lg">
                                <!-- Modal content-->
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                        <h4 class="modal-title" align="center"> Edit Item </h4>
                                    </div>
                                    <div class="modal-body">
                                       <form method="post" class="form-horizontal" role="form">


                 <div class="row">
                 <div class="col-md-6">
                	<div class="form-group">
                    <label for="form_name">Nome Cognome del Cliente *</label>
                    <input type="hidden"  name="id" value="<?php echo $row['id'] ; ?>" >
                    <input id="form_name" type="text" name="name"  value="<?php echo $row['nome'] ; ?>" class="form-control"
                    placeholder="" required="required" data-error="Firstname is required.">
                    <div class="help-block with-errors"></div>
                </div>
            </div>
             <div class="col-md-6">
                <div class="form-group">
                    <label for="form_phone">Telefono*</label>
                    <input id="form_phone" type="tel" name="phone" value="<?php echo $row['tel'] ; ?>" class="form-control"
                    placeholder="" required="required" data-error="Telephone-Number is required.">
                    <div class="help-block with-errors"></div>
                </div>
            </div>

       </div>

        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                     <label for="email">Email del cliente</label>
                    <input id="email" type="email" name="email"  value="<?php echo $row['email'] ; ?> "class="form-control"
                     placeholder=""  data-error="Valid email is required.">
                    <div class="help-block with-errors"></div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                   <label for="referente">Avvocato Riferimento</label>
						<input id="nome avvocato" type="text" value=" <?php echo $row['avocato'] ; ?>" name="avvocato" class="form-control"
                    placeholder="" required="required" >
                    <div class="help-block with-errors"></div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="form-group">
                    <label for="form_message">Messagio*</label>
                    <textarea id="form_message" name="message"    class="form-control"

                     rows="4" required data-error="Please,leave us a message."> <?php echo $row['note'] ; ?> </textarea>
                    <div class="help-block with-errors"></div>
                </div>
            </div>
		</div>
                                                 </div>


                                    <div class="modal-footer">
                                        <button type="submit" class="btn  btn-primary btn-md " name="update_item">
                                        <span class="glyphicon glyphicon-ok" ></span> Salva</button>

                                        <button type="button" class="btn btn-warning" data-dismiss="modal">
                                        <span class="glyphicon glyphicon-remove-circle"></span> Cancella</button>
                                     </div>
                                      </div>
                                     </div>
                                </div>
                            </div>
                        </form>
                    </div>
                    <?php
		}
		?>


	<?php
			if(isset($_POST['update_item'])){
				$id=$_POST['id'];
				$nome= $_POST['name'];
				$tel= $_POST['phone'];
				$email= $_POST['email'];
				$avvocato= $_POST['avvocato'];
				$note= $_POST['message'];
				$sql1="UPDATE  agenda SET nome='$nome', tel='$tel' , email= '$email', note='$note', avocato='$avvocato' WHERE id='$id'";
				if($conn->query($sql1)===TRUE) {
	echo "<meta http-equiv='refresh' content='0'>";


}
	else  {
		echo '';
	}
			}

		?>




  </tbody>

</table>

</div>

<!--/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// -->

	</div>










	</div>
	</div>

</body>
</html>
