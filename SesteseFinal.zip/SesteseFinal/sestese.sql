-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Creato il: Nov 22, 2019 alle 19:53
-- Versione del server: 5.5.57-MariaDB
-- Versione PHP: 5.6.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sestese`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `Cessione in strada`
--

CREATE TABLE `Cessione in strada` (
  `ID` int(11) DEFAULT NULL,
  `seriale` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `tecnico che cede` int(11) DEFAULT NULL,
  `tecnico che riceve` int(11) DEFAULT NULL,
  `dichiarante` int(11) DEFAULT NULL,
  `data` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Struttura della tabella `CLIENTE`
--

CREATE TABLE `CLIENTE` (
  `ID` int(11) DEFAULT NULL,
  `Cliente` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `Logo` mediumtext COLLATE utf8_bin
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dump dei dati per la tabella `CLIENTE`
--

INSERT INTO `CLIENTE` (`ID`, `Cliente`, `Logo`) VALUES
(1, 'SKY', 'sky.bmp'),
(2, 'FASTWEB', 'Fastweb.jpg'),
(3, 'TELECOM', 'Telecomnuovagiusta.jpg'),
(4, 'Ed.in.tec.', 'LOGO EDINTEC.jpg');

-- --------------------------------------------------------

--
-- Struttura della tabella `Conteggio Magazzino`
--

CREATE TABLE `Conteggio Magazzino` (
  `ID` int(11) DEFAULT NULL,
  `Prodotto` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `Giacenza_Fiscale` int(11) DEFAULT NULL,
  `Giacenza_Tecnici` int(11) DEFAULT NULL,
  `Giacienza_Fisica` int(11) DEFAULT NULL,
  `cliente` varchar(50) COLLATE utf8_bin DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dump dei dati per la tabella `Conteggio Magazzino`
--

INSERT INTO `Conteggio Magazzino` (`ID`, `Prodotto`, `Giacenza_Fiscale`, `Giacenza_Tecnici`, `Giacienza_Fisica`, `cliente`) VALUES
(1, 'Pi2', 2, 1, 1, 'Ed.in.tec.'),
(2, 'RaspBerry PI', 1, 0, 1, 'Ed.in.tec.');

-- --------------------------------------------------------

--
-- Struttura della tabella `Copia di Conteggio Magazzino`
--

CREATE TABLE `Copia di Conteggio Magazzino` (
  `ID` int(11) DEFAULT NULL,
  `Prodotto` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `Giacenza_Fiscale` int(11) DEFAULT NULL,
  `Giacenza_Tecnici` int(11) DEFAULT NULL,
  `Giacienza_Fisica` int(11) DEFAULT NULL,
  `cliente` varchar(50) COLLATE utf8_bin DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Struttura della tabella `Dettaglio Prodotto`
--

CREATE TABLE `Dettaglio Prodotto` (
  `ID` int(11) DEFAULT NULL,
  `Modello` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `Descrizione` mediumtext COLLATE utf8_bin,
  `Foto` mediumtext COLLATE utf8_bin,
  `Codice` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `Prezzo` int(11) DEFAULT NULL,
  `Cliente` int(11) DEFAULT NULL,
  `barcode128` varchar(50) COLLATE utf8_bin DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dump dei dati per la tabella `Dettaglio Prodotto`
--

INSERT INTO `Dettaglio Prodotto` (`ID`, `Modello`, `Descrizione`, `Foto`, `Codice`, `Prezzo`, `Cliente`, `barcode128`) VALUES
(1, 'Ts-251A', 'QNAP 2-Bay Turbo NAS', 'ts251a.jpg', '471251112972', 200, 2, 'ÒO,S+=h7Ó'),
(2, 'UV-5R', 'Baofeng Bibanda', 'uv-5r.jpg', 'uv5r', 180, 2, 'Ñuv5r?Ó'),
(3, 'A58H', 'Siemens A58H', 'a58h.gif', 'a58h', 90, 1, 'Ña58hXÓ'),
(4, 'nuovo modello', 'modello di nuova concezione', '2.jpg', '1234', NULL, 2, 'Ò,BrÓ'),
(5, 'motore cancello', 'motore', 'ace.jpg', '3344', NULL, 4, NULL),
(6, 'Powernote', 'Powernote', 'erg.jpg', NULL, NULL, 4, NULL),
(7, 'Scanner', 'Scannner BARCODE', 'ls2208-corded_800_600.png', '8026974014845', NULL, 4, NULL),
(8, 'BDV', 'BDV', 'business_people_06.jpg', '10034785506511', 0, 1, NULL),
(9, 'RaspBerry PI', 'Mini PC', '8. BackTrack Silver Dragon by PCbots.png', '640522710566', 0, 4, NULL),
(10, 'Bimbostore', 'Bit4id', '1.jpg', '6666623142639', 0, 4, NULL),
(11, 'Pi2', 'Rasp pi2', '5.jpg', '640522710515', 0, 4, NULL),
(12, 'penna', 'penna', 'caffe.jpg', '990088', 0, 4, NULL),
(13, 'Lettore SMARTCARD', 'Lettore SMARTCARD', NULL, '110004514', 15, 4, NULL),
(14, 'Qbricks', 'Mattoncini', 'forni72.jpeg', '8051040553096', 2, 2, NULL),
(15, 'DECODER 183', 'Decoder di prova sestese', 'img_dec_SkyHD_Pace_DS830NS.jpg', 'M183', 0, 1, NULL),
(16, 'Decoder U183', 'Decoder2', 'img_dec_mySky_pace_TDS460NS.jpg', 'U183', 0, 1, NULL),
(17, 'SkyQ', 'SkyQ', 'se6fr3zRLKN9rKhiJbHTyV-480-80.jpg', '32B1', 0, 1, NULL),
(18, 'SKY MINI', 'SKY MINI', 'Untitled.png', '32D0', 0, 1, NULL),
(19, 'Decoder SKY 676', 'Decoder SKY 676 SAMSUNG', 'img_dec_SkyBox_Samsung_dolby_digital.jpg', '6763', 0, 1, NULL),
(20, 'DECODER AF0D', 'DECODER 6F0D PACE', 'img_dec_SkyHD_Pace_DS830NS.jpg', 'AF0D', 0, 1, NULL),
(21, 'AF13', 'DECODER AF13', 'img_dec_mySky_pace_TDS460NS.jpg', 'AF13', 0, 1, NULL),
(22, 'CB0C', 'DECODER CB0C', 'Untitled.png', 'CB0C', 0, 1, NULL),
(23, 'Decoder CB0D', 'Decoder CB0D', 'Decoder-Satellitare-4K-Dual-Tuner-Dvb-T2-s2-Hevc.jpg', 'CB0D', 0, 1, NULL),
(24, 'Decoder AF12', 'Decoder AF12', 'decoderskyboxf3.jpg', 'AF12', 0, 1, NULL),
(25, 'Decoder 9E0E', 'Decoder 9e0e', 'DIGIQUEST-tivusat-HD.jpg', '9e0e', 0, 1, NULL),
(99, 'test', 'test99', NULL, '999', NULL, 1, NULL);

-- --------------------------------------------------------

--
-- Struttura della tabella `LOG`
--

CREATE TABLE `LOG` (
  `ID` int(11) DEFAULT NULL,
  `Data` datetime DEFAULT NULL,
  `Utente Inserimento log` int(11) DEFAULT NULL,
  `TEC Origine` int(11) DEFAULT NULL,
  `TEC Destinatario` int(11) DEFAULT NULL,
  `Oggetto SN` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `INST Destinatario` int(11) DEFAULT NULL,
  `INST Origine` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dump dei dati per la tabella `LOG`
--

INSERT INTO `LOG` (`ID`, `Data`, `Utente Inserimento log`, `TEC Origine`, `TEC Destinatario`, `Oggetto SN`, `INST Destinatario`, `INST Origine`) VALUES
(685, '2019-05-02 11:20:35', 1, 0, 0, '6763A306707757925', 0, 9),
(686, '2019-05-02 11:20:35', 1, 0, 0, '6763A306731251143', 0, 9),
(687, '2019-05-02 11:20:35', 1, 0, 0, '6763A306732346595', 0, 9),
(688, '2019-05-02 11:20:35', 1, 0, 0, '6763A306732749434', 0, 9),
(689, '2019-05-02 11:20:35', 1, 0, 0, '6763A306732759177', 0, 9),
(690, '2019-05-02 11:20:35', 1, 0, 0, '9E0E040358255067A', 0, 9),
(691, '2019-05-02 11:20:35', 1, 0, 0, 'AF0D0603368572712', 0, 9),
(692, '2019-05-02 11:20:35', 1, 0, 0, 'AF13020492159455E', 0, 9),
(693, '2019-05-02 11:20:35', 1, 0, 0, 'AF130404925971313', 0, 9),
(694, '2019-05-02 11:20:35', 1, 0, 0, 'CB0C0203873726263', 0, 9),
(695, '2019-05-02 11:20:35', 1, 0, 0, 'CB0D0203660677610', 0, 9),
(696, '2019-05-02 11:20:49', 1, 0, 3, '6763A306731251143', 0, 0),
(697, '2019-05-02 11:20:49', 1, 0, 3, 'AF0D0603368572712', 0, 0),
(698, '2019-05-02 11:23:42', 1, 0, 3, '6763A306731251143', 0, 0),
(699, '2019-05-02 11:23:42', 1, 0, 3, 'AF0D0603368572712', 0, 0),
(700, '2019-05-02 11:26:19', 1, 0, 0, '6763A306731251143', 7, 0),
(701, '2019-05-02 11:26:19', 1, 0, 0, 'AF0D0603368572712', 7, 0),
(702, '2019-05-02 11:26:19', 1, 0, 0, 'AF130404925971313', 7, 0),
(703, '2019-05-02 11:26:19', 1, 0, 0, 'CB0C0203873726263', 7, 0),
(NULL, '2019-05-06 18:26:11', 1, NULL, NULL, '9999999', NULL, 9);

-- --------------------------------------------------------

--
-- Struttura della tabella `MAGAZZINO`
--

CREATE TABLE `MAGAZZINO` (
  `ID` int(11) DEFAULT NULL,
  `Seriale` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `MAC ADDRESS` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `Modello` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `Data Ingresso` datetime DEFAULT NULL,
  `Data Uscita` datetime DEFAULT NULL,
  `Service` int(11) DEFAULT NULL,
  `tecnico` bit(1) DEFAULT NULL,
  `installato` bit(1) DEFAULT NULL,
  `ODL` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `Data installazione` datetime DEFAULT NULL,
  `Nome Tecnico` int(11) DEFAULT NULL,
  `Service installato` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `Prezzo` int(11) DEFAULT NULL,
  `Posizione` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `Codice` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `qta` int(11) DEFAULT NULL,
  `RESO` bit(1) DEFAULT NULL,
  `Codice128` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `consegnato a sky` bit(1) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dump dei dati per la tabella `MAGAZZINO`
--

INSERT INTO `MAGAZZINO` (`ID`, `Seriale`, `MAC ADDRESS`, `Modello`, `Data Ingresso`, `Data Uscita`, `Service`, `tecnico`, `installato`, `ODL`, `Data installazione`, `Nome Tecnico`, `Service installato`, `Prezzo`, `Posizione`, `Codice`, `qta`, `RESO`, `Codice128`, `consegnato a sky`) VALUES
(NULL, 'AF13020492159455E', NULL, 'AF13', '2019-05-07 16:08:21', NULL, 9, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'AF13', 1, b'0', 'ÑAFÌ-\"$|/~WÍEmÓ', NULL),
(NULL, 'CB0C0203873726263', NULL, 'CB0C', '2019-05-07 16:08:21', NULL, 9, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'CB0C', 1, b'0', 'ÑCB0CÌ\"#wE::Í3?Ó', NULL),
(NULL, 'AF130404925971313', NULL, 'AF13', '2019-05-07 16:08:21', NULL, 9, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'AF13', 1, b'0', 'ÑAFÌ-$$|[g?Í3uÓ', NULL),
(NULL, 'AF0D0603368572712', NULL, 'DECODER AF0D', '2019-05-07 16:08:21', NULL, 9, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'AF0D', 1, b'0', 'ÑAF0DÌ&#DuhgÍ2!Ó', NULL),
(NULL, '6763A306731251143', NULL, 'Decoder SKY 676', '2019-05-07 16:08:21', NULL, 9, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '6763', 1, b'0', 'Òc_ÍAÌ>c?9+KNÓ', NULL),
(NULL, '6763A306732759177', NULL, 'Decoder SKY 676', '2019-05-07 16:08:21', NULL, 9, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '6763', 1, b'0', 'Òc_ÍAÌ>c@k{m>Ó', NULL),
(NULL, '6763A306732749434', NULL, 'Decoder SKY 676', '2019-05-07 16:08:21', NULL, 9, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '6763', 1, b'0', 'Òc_ÍAÌ>c@j~B}Ó', NULL),
(NULL, '9999999', NULL, NULL, '2019-05-06 18:26:07', NULL, 9, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '9999', 1, b'0', 'ÒÌÌÌÍ9{Ó', NULL);

-- --------------------------------------------------------

--
-- Struttura della tabella `progressivo`
--

CREATE TABLE `progressivo` (
  `ID` int(11) DEFAULT NULL,
  `ddt` int(11) DEFAULT NULL,
  `rma` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dump dei dati per la tabella `progressivo`
--

INSERT INTO `progressivo` (`ID`, `ddt`, `rma`) VALUES
(1, 7, 2);

-- --------------------------------------------------------

--
-- Struttura della tabella `Service`
--

CREATE TABLE `Service` (
  `ID` int(11) DEFAULT NULL,
  `Service` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `Riferimenti tel` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `CLIENTE` int(11) DEFAULT NULL,
  `Memo` mediumtext COLLATE utf8_bin,
  `CLIENTE2` int(11) DEFAULT NULL,
  `CLIENTE3` int(11) DEFAULT NULL,
  `CLIENTE4` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dump dei dati per la tabella `Service`
--

INSERT INTO `Service` (`ID`, `Service`, `Riferimenti tel`, `CLIENTE`, `Memo`, `CLIENTE2`, `CLIENTE3`, `CLIENTE4`) VALUES
(1, 'RESI NEGOZIO', '99988252', 1, NULL, NULL, NULL, NULL),
(3, 'Senago Fibra', '654651231', 2, NULL, NULL, NULL, NULL),
(4, 'Douz Telecom', '0216541561', 3, NULL, NULL, NULL, NULL),
(5, 'A.B.C. Solution Provider', '3393095222', 1, 'tgt', 2, 3, 4),
(6, 'RESI', '020202', 1, NULL, 0, 0, 0),
(7, 'EDINTEC', NULL, 1, NULL, 0, 0, 0),
(8, 'ELLE ERRE DI LORENZI RENATO', NULL, 0, NULL, 0, 0, 0),
(9, 'SKY', NULL, 0, NULL, 0, 0, 0);

-- --------------------------------------------------------

--
-- Struttura della tabella `Test`
--

CREATE TABLE `Test` (
  `ID` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Struttura della tabella `Utenti`
--

CREATE TABLE `Utenti` (
  `ID` int(11) DEFAULT NULL,
  `Nome` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `Cognome` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `Password` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `Rif Telefonico` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `Tecnico` bit(1) DEFAULT NULL,
  `Foto` mediumtext COLLATE utf8_bin,
  `Indirizzo` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `codice sky` int(11) DEFAULT NULL,
  `cf` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `operatore` bit(1) DEFAULT NULL,
  `installer` bit(1) DEFAULT NULL,
  `service-link` int(11) DEFAULT NULL,
  `piva` varchar(11) COLLATE utf8_bin DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dump dei dati per la tabella `Utenti`
--

INSERT INTO `Utenti` (`ID`, `Nome`, `Cognome`, `Password`, `Rif Telefonico`, `Tecnico`, `Foto`, `Indirizzo`, `codice sky`, `cf`, `operatore`, `installer`, `service-link`, `piva`) VALUES
(1, 'Angelo', 'Belverato', 'lgonpk', '112233', b'0', '2018-08-09 18.43.47.jpg', NULL, NULL, NULL, b'1', b'0', NULL, NULL),
(2, 'Olfa', 'Gharsallah', 'habibti', '3334466734', b'1', '2018-08-09 20.24.53.jpg', NULL, NULL, NULL, b'0', b'0', NULL, NULL),
(3, 'Luca', 'Voltolin', '1234', '156561', b'1', 'LUCA.jpg', NULL, NULL, NULL, b'0', b'0', NULL, NULL),
(4, 'EDINTEC', 'INSTALLER', NULL, NULL, b'0', 'LOGO EDINTEC.jpg', NULL, NULL, NULL, b'0', b'0', 7, NULL),
(5, 'ELLE ERRE DI LORENZI RENATO', 'INSTALLER', NULL, NULL, b'0', NULL, 'VIA XXIV MAGGIO 64 CORMANO', 264, NULL, b'0', b'0', 8, '07530830962'),
(6, 'SKY', NULL, NULL, NULL, b'0', NULL, NULL, 0, NULL, b'0', b'0', 2, NULL);

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `Test`
--
ALTER TABLE `Test`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `Test`
--
ALTER TABLE `Test`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
