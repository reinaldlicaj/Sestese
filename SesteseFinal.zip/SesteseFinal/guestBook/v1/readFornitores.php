<?php
include  'Connections.php';
/////// get data if is regisred before//////////
	if (isset($_POST['codeF'])) {
		$codeF = $_POST['codeF'];
		
$sql = "SELECT * FROM visitatori WHERE code ='$codeF' ";
$r = mysqli_query($conn,$sql);
$result = array();
while($row = mysqli_fetch_array($r)){
 array_push($result,array(
	'id'=>$row['id'],
	 'fornitore'=>$row['fornitore'],
    'nome'=>$row['nome'],
	 'cognome'=>$row['cognome'],
	  'referente'=>$row['referente'],
	 'ruolo'=>$row['ruolo'],
	  'email'=>$row['email'],
	  'presente'=>$row['presente']
    ));
}
echo json_encode(array('result'=>$result));
mysqli_close($conn);
	}

//////////// update in uscita della persona///////////

if(isset($_POST['id'])){
	    $idF =$_POST['id'];
		date_default_timezone_set("Europe/Rome");
        $data = date('Y-m-d H:i:s');
	$sql1 = "UPDATE fornitore SET dataOraUscita='$data', 
	presente='0' WHERE id='$idF'";
	if($conn->query($sql1)==TRUE){
		
	}
	
 $sql2="SELECT * FROM visitatori  WHERE idF='$idF' ";
	$r = mysqli_query($conn,$sql2);
$result = array();
while($row = mysqli_fetch_array($r)){
 array_push($result,array(
	'referente'=>$row['referente'],
	
    ));
	
}
	echo json_encode(array('result'=>$result));
mysqli_close($conn);
}


?>