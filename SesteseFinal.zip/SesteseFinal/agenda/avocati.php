<!DOCTYPE html>
<html lang="en">
<head>
  <title>Test</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  <script type="text/javascript" src="js/addons/datatables.min.js"></script>
  <link href="css/addons/datatables.min.css" rel="stylesheet">
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
     <link href="Style.css" rel="stylesheet">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
   <link href="lawyer.ico" rel="icon" type="image/x-icon" />
  <style>


  </style>
  <script>
$(document).ready(function () {
$('#dtBasicExample').DataTable();
$('.dataTables_length').addClass('bs-select');
});

	</script>
</head>
<body>

<div class="container-fluid">
  <div class="row content">

    <div class="col-sm-3 sidenav">
       <a class="navbar-brand" href="#">
          <img src="avLogo.png" alt="">
        </a>

      <h4>Segreteria  Avvocati</h4><br/>
      <ul class="nav nav-pills nav-stacked">
        <li><a href="index.php"><i class="fas fa-home "></i>  HOME</a></li>
        <li><a href="agpage.php"><i class="fas fa-book" ></i> AGENDA</a></li>
        <li  class="active"><a href="avocati.php"><i class="fas fa-user-tag"></i> AVVOCATI</a></li>

      </ul><br>

    </div>



    <div class="col-sm-9 areanav">
   <!-- /////////////////////////////////////////////////////////////////pagina che si scambia-->


     <div class="jumbotron jumbotron-fluid">
  <div class="container">
   <h1 >Avvocati

     <button type="button" class="btn  btn-primary btn-md"  data-toggle="modal" data-target="#myModal" >
         <span class="glyphicon glyphicon-plus-sign"></span> INSERISCI
       </button>

    </h1>
  </div>
</div>



     <div class="container">
       <div class="table-responsive">

     <table id="dtBasicExample" class="table  table-bordered table-hover" cellspacing="0"
  width="100%">
  <thead>
    <tr>
      <th class="th-sm">Avvocato
          <span class="glyphicon glyphicon-sort" ></span>

      </th>
      <th class="th-sm">Telefono

		</th>
      <th class="th-sm">Email

      </th>

    </tr>
  </thead>
  <tbody>


     <?php
		include("connect.php");
			$sql= "select * from avvocati";
		$result= mysqli_query($conn, $sql);
		while($row=mysqli_fetch_array($result)){
			echo'
			  <tr>
      <td class="td1" >'.$row['nome'].'</td>
      <td>'.$row['telefono'].'</td>

      <td>'.$row['email'].'</td>

    </tr>

			';
		}
		?>


  </tbody>

</table>



  <!-- Modal for addin Avvocato -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">

      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Aggiungi Avvocato</h4>
        </div>
        <div class="modal-body">
  <form method="post" class="form-horizontal" role="form">
 <div class="row">
 <div class="col-md-6">
 <div class="form-group">
 <label for="form_name">Avvocato*</label>

 <input id="form_name" type="text" name="name"  value="" class="form-control"
 placeholder="" required="required" data-error="Firstname is required.">

 </div>
 </div>
 </div>
  <div class="row">
 <div class="col-md-6">
 <div class="form-group">
 <label for="form_phone">Telefono*</label>
 <input id="form_phone" type="tel" name="phone" value="" class="form-control"
 placeholder="" required="required" data-error="Telephone-Number is required.">

 </div>
 </div>

 </div>


 <div class="row">
 <div class="col-md-6">
 <div class="form-group">
 <label for="email">Email* </label>
 <input id="email" type="email" name="email"  value=" "class="form-control" required="required"
 placeholder=""  data-error="Valid email is required.">

 </div>
 </div>
  </div>

</div>


        <div class="modal-footer">
          <button type="submit" class="btn  btn-primary btn-md" name="add_person">
          <span class="glyphicon glyphicon-ok" ></span> Salva</button>

          <button type="button" class="btn btn-warning" data-dismiss="modal">
          <span class="glyphicon glyphicon-remove-circle"></span> Cancella</button>
        </div>
      </div>
</form>
    </div>
  </div>
  <?php
      if(isset($_POST['add_person'])){
        $id=$_POST['id'];
        $nome= $_POST['name'];
        $tel= $_POST['phone'];
        $email= $_POST['email'];

        $sql1="INSERT INTO  avvocati (id, nome, telefono,email) VALUE ('','$nome', '$tel' , '$email') ";
        if($conn->query($sql1)===TRUE) {
  echo "<meta http-equiv='refresh' content='0'>";
}
  else  {
    echo '';
  }
      }

    ?>


</div>

<!--/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// -->

	</div>
	</div>
	</div>
	</div>

</body>
</html>
