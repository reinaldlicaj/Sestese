
<?php 
include 'Connections.php';

if(isset($_POST['nomeR'],$_POST['cognomeR'])){
	$nomeR = $_POST['nomeR'];
	$cognomeR =$_POST['cognomeR'];
	$sql1 = "SELECT * FROM referenti WHERE nomeR='$nomeR' AND cognomeR='$cognomeR' ";
	$r1 = mysqli_query($conn,$sql1);
$result1 = array();
while($row = mysqli_fetch_array($r1)){
 array_push($result1,array(
	  'emailR'=>$row['emailR'],
	 'telefonoR'=>$row['telefonoR']
    ));
}
echo json_encode(array('result'=>$result1));
mysqli_close($conn);		
}



else{
	
	
$sql = "SELECT * FROM referenti";

//$con=mysqli_connect(DB_HOST,DB_USER,DB_PASSWORD,DB_DATABASE);
$r = mysqli_query($conn,$sql);
$result = array();
while($row = mysqli_fetch_array($r)){
 array_push($result,array(
	 'idR'=>$row['idR'],
      'nomeR'=>$row['nomeR'],
	 'cognomeR'=>$row['cognomeR'],
	  'emailR'=>$row['emailR'],
    ));
}
echo json_encode(array('result'=>$result));
mysqli_close($conn);
	}
?>





 
