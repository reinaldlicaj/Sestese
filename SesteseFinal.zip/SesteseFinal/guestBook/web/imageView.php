
<?php
    include 'include/controller.php';
    if(isset($_GET['image_id'])) {
        $sql = "SELECT firma, qrcode FROM visitatori WHERE id=" . $_GET['image_id'];
		$result = mysqli_query($conn, $sql) or die("<b>Error:</b> Problem on Retrieving Image BLOB<br/>" . mysqli_error($conn));
		$row = mysqli_fetch_array($result);
		header("Content-type: " . $row["imageType"]);
        echo $row["qrcode"];
	}
	mysqli_close($conn);
?>