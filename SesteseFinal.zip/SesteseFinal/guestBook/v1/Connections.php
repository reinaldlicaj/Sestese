<?php 
 $servername = "localhost";
$uname = "root";
$password = "admin";
$dbname = "registroDB";
$conn = mysqli_connect($servername, $uname, $password, $dbname) or die('Unable to Connect');
?>