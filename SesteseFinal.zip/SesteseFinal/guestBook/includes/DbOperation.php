<?php
date_default_timezone_set("Europe/Rome");
                 $data = date('Y-m-d H:i:s');
class DbOperation
{
    //Database connection link
    private $con;

    //Class constructor
    function __construct()
    {
        //Getting the DbConnect.php file
        require_once dirname(__FILE__) . '/DbConnect.php';

        //Creating a DbConnect object to connect to the database
        $db = new DbConnect();

        //Initializing our connection link of this class
        //by calling the method connect of DbConnect class
        $this->con = $db->connect();
    }
	
		

	/*
	* The create operation
	* When this method is called a new record is created in the database
	*/
	
	
	function addFornitor($nome,$cognome,$email,$referente,$fornitore, $ruolo,$motivo,$firma,$code,$qrcode,$data,$presente,$tipo){
		
		$stmt = $this->con->prepare("INSERT INTO visitatori (nome,cognome,email,referente,fornitore,ruolo,motivo,firma,code,qrcode,dataOraEntrata,presente,tipo)
		
		VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)");
		
		date_default_timezone_set("Europe/Rome");
        $data = date('Y-m-d H:i:s'); 
		$presente= 1;
		$tipo='F';
		
		$stmt->bind_param("sssssssssssis", $nome,$cognome,$email, $referente, $fornitore,
						  $ruolo, $motivo,$firma,$code,$qrcode,$data,$presente,$tipo );

		if($stmt->execute()){
				return true;
		}

			else{
					return false;
			}



	}

	/*
	* The read operation
	* When this method is called it is returning all the existing record of the database
	*/
	function getFornitores(){
		$stmt = $this->con->prepare("SELECT  nome,cognome, presente FROM visitatori WHERE presente='1' AND tipo='F' ");
		$stmt->execute();
		$stmt->bind_result($nome, $cognome, $presente);

		$fornitores = array();

		while($stmt->fetch()){
			$fornitore = array();	
			$fornitore['nome'] = $nome;
			$fornitore['cognome'] = $cognome;
			$fornitore['presente'] = $presente;
			array_push($fornitores, $fornitore);
		}

		return $fornitores;
	}
	
	/* read just all the Codes of fornitores*/
		function getCodeFornitores(){
		$stmt = $this->con->prepare("SELECT code FROM fornitore ");
		$stmt->execute();
		$stmt->bind_result($codeF);

		$fornitores = array();

		while($stmt->fetch()){
			$fornitore = array();
			$fornitore['code'] = $code;
			array_push($fornitores, $fornitore);
		}

		return $fornitores;
	}



		/* The create operation
	* When this method is called a new record is created in the database
	*/
	function createReferente($nomeR, $cognomeR, $emailR,$telefonoR, $ruoloR){
	$stmt = $this->con->prepare("INSERT INTO referenti (nomeR, cognomeR, emailR,telefonoR, ruoloR)
	VALUES (?, ?, ?, ?,?)");
		$stmt->bind_param("sssss", $nomeR, $cognomeR, $emailR, $telefonoR,$ruoloR);
		if($stmt->execute())
			return true;
		return false;
	}
	

	function getReferents(){
		$stmt = $this->con->prepare("SELECT nomeR, cognomeR  FROM referenti");
		$stmt->execute();
		$stmt->bind_result($nomeR, $cognomeR);

		$referents = array();

		while($stmt->fetch()){
			 $referent  = array();
			
			 $referent['nomeR'] = $nomeR;
			 $referent['cognomeR'] = $cognomeR;
			

			array_push($referents, $referent);
		}

		return $referents;
	}

		/* The create operation
	* When this method is called a new record is created in the database
	*/
	function createVisitor($nome,$cognome,$email,$referente,$azienda,$ruolo,
						   $firma, $code,$qrcode, $dataOraEntrata, $presente,$tipo){
		
		$stmt = $this->con->prepare("INSERT INTO visitatori (nome,cognome,email,referente,
		azienda,ruolo,firma, code, qrcode,dataOraEntrata, presente,tipo)
		VALUES (?,?,?,?,?,?,?,?,?,?,?,?)");
		
			date_default_timezone_set("Europe/Rome");
                 $data = date('Y-m-d H:i:s');
		$presente=1;
		$tipo ='V';
		$stmt->bind_param("ssssssssssis",$nome,$cognome,$email,$referente,$azienda,$ruolo,
						   $firma,$code,$qrcode,$dataOraEntrata,$presente,$tipo);
		if($stmt->execute()){
			return true;
		}
		else{
			return false;	
		}
			
	
	}
	
	function getVisitors(){
		$stmt = $this->con->prepare("SELECT  nome, cognome FROM visitatori WHERE presente='1' AND tipo='V' ");
		$stmt->execute();
		$stmt->bind_result($nome,$cognome);
		$visitori = array();
		while($stmt->fetch()){
			 $visitor = array();
			
			 $visitor['nome'] = $nome;
			 $visitor['cognome'] = $cognome;
		
			array_push($visitori, $visitor);
		}
		return $visitori;
	}
	
	
		
	function getCodeVisitors(){
		$stmt = $this->con->prepare("SELECT  codeV FROM visitatori");
		$stmt->execute();
		$stmt->bind_result($codeV);
		$visitori = array();
		while($stmt->fetch()){
			 $visitor = array();
			
			 $visitor['codeV'] = $codeV;
			
		
			array_push($visitori, $visitor);
		}
		return $visitori;
	}
}
?>
