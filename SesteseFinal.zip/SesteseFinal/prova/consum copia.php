<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Documento senza titolo</title>
</head>

<body>
</body>
</html><!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="refresh" content="600" >

<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
<meta name="viewport" content="width=device-width, initial-scale=1" />
<link rel="stylesheet" href="styles1.css">
<title>Order Form </title>

<link rel="stylesheet" href="/lib/css/page_v2.css" />
<link rel="stylesheet" media="screen and (max-width: 900px)" href="/lib/css/small_v2.css" />
<script src="/lib/js/page_v2.js" type="text/javascript"></script>
<link rel="stylesheet" href="includes/order_form.css" type="text/css" />
<script src="includes/order_form.js" type="text/javascript"></script>
	<script>
function goBack() {
  window.history.back() }   </script>
	<script type="text/javascript"  >
 	function closebtn() {    document.getElementById("myClose").style.display = "none";  }    </script>

<script>
funcion check(){
document.getElementsById('f1').innerHTML ;
}
</script>
		 <style>
.alert {
padding: 20px;
width:400px;
background-color: #f44336;
color: white;
}
.closebtn {
margin-left: 15px;
color: white;
font-weight: bold;
float: right;
font-size: 22px;
line-height: 20px;
cursor: pointer;
transition: 0.3s;
}
.closebtn:hover {
color: black;
}
</style>
</head>
<body>
<?php
include('conn.php');
	if (isset($_POST['submit1'])) {
	$mod = $_POST['modello'] ;
	$id_modello= $_POST['id_modello'];
	$matricolla= $_POST['matricolla'];
	$codice_cliente =$_POST['id_cliente'];
	$contatore = $_POST['contatore'] ;
	$sql="SELECT * FROM consumabili  INNER JOIN macchine ON consumabili.id_modello=macchine.id_modello  Where macchine.matricolla='$matricolla' ";
	$result = mysqli_query($conn,$sql) or die (mysqli_error($conn));
	$numberOfRows = mysqli_num_rows($result);
echo "<table border='1px'  >";
	echo '<form method="post" action=""  name="myform" >  ';

echo'<tr><th colspan="4">CONSUMABILI DEL MODELLO:<input size="25" type="text" name="modeli" value="'.$mod.'"><input size="15" type="text" name="matricolla" value="'.$matricolla.'"></th>
</tr>';
echo " <tr><th hidden></th><th>Codice: </th><th>Descrizione:</th> <th>Quantità:</th></tr>";
while($row= mysqli_fetch_array($result) )
 {
 echo '<tr>';
echo '<td hidden> <input type="text" size="5" name="id[]" value="'. $row['id_consumabili'].'"></td>';
echo '<td width=20% class="first"><input type="text" size="20" name="codice[]" value="'. $row['codice'].'"></td>';
echo '<td width=30% ><input type="text" size="50" name="descr[]" value="'. $row['descrizione'].'"></td>';
echo '<td  hidden><input type="text" size="50" name="id_mod" value="'. $row['id_modello'].'"></td>';

echo   '<td class="qty" width=15% > <input class="cur"  type="text" name="qnt[]" value=" '. $row['quantita'].' " maxlength="2" size="2" /></td>';
	echo "</tr>";
  }
		echo "<tr class='order'>";
	echo '<td > Contatore Bianco e Nero <input type="number"  size="20" name="contatore"  maxlength="7" value=""  required >';

	$sql3="SELECT * from macchine WHERE  id_modello='$id_modello'";
		$result3 = mysqli_query($conn,$sql3) or die (mysqli_error($conn));
			$row3= mysqli_fetch_array($result3);
			$colore=$row3['contatorecolore'];
			$contatorea=$row3['contatore'];
	if ($colore>0){
		echo ' Contatore Colore <input type="number" size="20" name="contatore2"  maxlength="7"   value=""  required ></td>';
	}
		echo '<td  colspan="7"  align="center"><input  type="submit"  onclick="goBack()"   class="submit1" name="ordina"   value="PROSEGUI" />';
		echo '<input type="hidden"  name="numberOfRows"  value="'.$numberOfRows.'">';
	echo '<input type="text"  hidden name="contatorea"  value="'.$contatorea.'">';
			echo '<input  type="text"  hidden name="contatoreB"  value="'.$colore.'">';

		echo "</form>";
	    echo '</tr>';
 }
 echo '<tr>';

	 if (isset($_POST['ordina'])){
		 $msg="";
		$id_modello=$_POST['id_mod'];
		$contatore=$_POST['contatore'];
	 $contatore2=$_POST['contatore2'];
		  $contatorea =$_POST['contatorea'];
		$contatoreB =$_POST['contatoreB'];
		date_default_timezone_set("Europe/Rome");
	 $lettura= date("Y/m/d -  H:i");


	if ($contatore <= $contatorea )  {
		 $msg.=" Valore contatore B/N  non valido!";

		}
	 if  ($contatore > $contatorea )  {
		 if($contatore2 > 0 ) {

		if ( $contatore2 <= $contatoreB ){
			$msg.=" valore cont a colore  non è valido";
			 }
			 	 }
				  echo '</tr>';
				 	echo "</table>";
$sql1= "SELECT * FROM cliente WHERE id_cliente = ( SELECT id_cliente FROM macchine WHERE id_modello='".$id_modello."')";
	             $result = mysqli_query($conn,$sql1) or die (mysqli_error($conn));
							 $row= mysqli_fetch_array($result);
							 $nome_cliente = $row2['nome_cliente'];
		           $sql2= " SELECT * FROM macchine WHERE id_modello= '$id_modello'";
							 $result1 = mysqli_query($conn,$sql2) or die (mysqli_error($conn));
							 $row2= mysqli_fetch_array($result1);
							 $email= $row['email'];
							 $modello = $row2['modello'];
							 $matricolla = $row2['matricolla'];
	             $id_cliente = $row2['id_cliente'];
	             $dt_inserimento = $row2['dt_inserimento'];
	             $durata_contratto= $row2['durata_contratto'];
							 $nome_cliente= $row['nome_cliente'];
							 $numberOfRows= $_POST['numberOfRows'];
						 	$sql3 = "UPDATE macchine SET
						 	id_modello='$id_modello',modello='$modello',matricolla='$matricolla',	contatore='$contatore', contatorecolore='$contatore2',	lettura='$lettura',
               id_cliente= '$id_cliente',dt_inserimento='$dt_inserimento',durata_contratto='$durata_contratto', aggiungi='',modifica='',cancella='' Where id_modello ='$id_modello' " ;
						 if($conn->query($sql3)===TRUE){    $msg.=" UPDATET"; }
						 else {     $msg.=" not  UPDATET";     }


               $to =" info@sara-enterprise.com";
							 $subject = "ORDINE Multifunzione $nome_cliente  ";
							 $header="From:'.$email.'"   ;
							 $message = "Contenuto del Ordine per il modello   $modello   dal cliente   $nome_cliente : \n ";   	echo "$message ,  $email	";
				 	echo '<table border="1">';
							echo '<tr> <th>Codice </th><th>Descrizione</th> <th>Quantità</th> </tr>';

					$id =$_POST['id'];   $codice = $_POST['codice'];  $descr= $_POST['descr'];   $qnt = $_POST['qnt'];
							 if ( is_array( $qnt)){
							 for($i=0; $i<$numberOfRows; $i++){
								      $id1 = $id[$i];    $codice1 =  $codice [$i];  $descr1= $descr[$i];   $qnt1 = $qnt [$i];
											$sql4= "UPDATE consumabili SET id_consumabili='$id1', codice='$codice1', descrizione='$descr1', id_modello='$id_modello', modello='$modello',
											id_cliente='$id_cliente', quantita='$qnt1', modifica='', cancella=''  Where id_consumabili='$id1' ";
				 if($conn->query($sql4)===TRUE){
					 $msg="UPDATET con quantita";
							}
						else {
							   $msg=" not UPDATET qnt";
													 }
													 if ($qnt1>0) {
													 $sql5="INSERT INTO ordini (id_ordine,id_cliente, nome_cliente, modello,codicec, descr, quantita, data )
													 VALUES ('','$id_cliente', '$nome_cliente', '$modello','$codice1', '$descr1', '$qnt1', '$lettura')";
														if($conn->query($sql5)===TRUE){
															$msg1="inserted to ordini";
																 }
															 else {
																		$msg1=" not inserted";
																							}
	 echo   ' <tr><td>'.$codice1.'</td> <td> '.$descr1.' </td> <td> '.$qnt1.'</td> </tr>  ';
	}
 }
}
					  echo '</table>';
	}
		 echo '<p id=‘f1’><div  id="myClose"   class="alert">
  <span  class="closebtn" onclick="closebtn();" >&times;</span>
  <strong></strong>  '.$msg.' '.$msg1.'
</div></p>';
}

?>
</body>
</html>
