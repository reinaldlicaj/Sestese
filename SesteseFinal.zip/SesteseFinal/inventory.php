<?php
include 'include/controller.php';
$session_username = $_SESSION['username'];
$session_idu = $_SESSION['id'];
$install="0";
if(empty($_SESSION['username'])){
    header("location:login.php");
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Pannello Tecnico</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-theme.min.css">
    <link rel="stylesheet" href="css/loader.css">
    <script src="js/jquery-1.12.4.js"></script>
    <link rel="stylesheet" type="text/css" href="dashboard/vendor/font-awesome/css/font-awesome.min.css">
    <script>
        $(document).ready(function() {
                $('#example').DataTable({});
            });

        </script>
    <link rel="stylesheet" href="css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="css/dataTables.bootstrap.min.css">
    <link rel="stylesheet" href="css/responsive.bootstrap.min.css">
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.dataTables.min.js"></script>

    <script type="text/javascript" >

    $(function(){
     $('#reso').on('click', function(){
         if($(this).is(':checked')){
             $('#mac').attr('disabled', false);
         } else {
             $('#mac').attr('disabled', true);
         }
     });


  });
    </script>
</head>

<body onload="myFunction()" style="margin:0;">
  <div class="smth">
    <div class="container">
        <div class="dropdown">
            <button class="btn btn-primary dropdown-toggle btn-sm" type="button" data-toggle="dropdown"><span class='glyphicon glyphicon-user' aria-hidden='true'></span>
                <?php echo $session_username ; ?> <span class="caret"></span></button>
            <ul class="dropdown-menu">
                <li><a href="#logout" data-toggle="modal"><span class='glyphicon glyphicon-log-out' aria-hidden='true'></span>Disconnettersi</a></li>
              <!--  <li><a href="#changepass" data-toggle="modal"><span class='glyphicon glyphicon-edit' aria-hidden='true'></span> Change Password</a></li>-->
            </ul>
              <!--
            <a href="#add" data-toggle="modal">
                <button type='button' class='btn btn-success btn-sm'><span class='glyphicon glyphicon-plus' aria-hidden='true'></span> Job</button>
            </a>
          -->
        </div>
        <br>
        <table id="example" class="display nowrap" cellspacing="0" width="100%">
            <thead>
                <tr>

                    <th>Seriale</th>
                    <th>DATA USCITA</th>
                    <th>Installato</th>
                    <th>ODL</th>
                    <th>Nome Tecnico</th>
                    <th>Installazione</th>

                </tr>
            </thead>


            <tbody>
                <?php
                    $sql = "SELECT MATERIALETECNICIODBC.ID,MATERIALETECNICIODBC.Seriale,MATERIALETECNICIODBC.MACADDRESS,MATERIALETECNICIODBC.Modello,MATERIALETECNICIODBC.DataIngresso,MATERIALETECNICIODBC.DataUscita,MATERIALETECNICIODBC.installato, MATERIALETECNICIODBC.ODL, MATERIALETECNICIODBC.Datainstallazione, MATERIALETECNICIODBC.NomeTecnico  FROM MATERIALETECNICIODBC WHERE installato='0' AND NomeTecnico='$session_idu' ";
                    $result = $conn->query($sql);
                    if ($result->num_rows > 0) {
                        // output data of each row
                        while($row = $result->fetch_assoc()) {
                            $id= $row['ID'];
                            $serial = $row['Seriale'];
                            $macaddress = $row['MACADDRESS'];
                            $model = $row['Modello'];
                            $entrydate = $row['DataIngresso'];
                            $exitdate = $row['DataUscita'];
                            $installed = $row['installato'];
                            $c=explode(",",$installed);
                            $odl = $row['ODL'];
                            $installationdate = $row['Datainstallazione'];
                            $tecnicname = $row['NomeTecnico'];


                    ?>
                <tr>

                    <td>
                        <?php echo $serial; ?>
                    </td>


                    <td>
                        <?php echo $exitdate; ?>
                    </td>


                    <td>
                      <input type="checkbox" name="installed" value="1"
  <?php
  if (in_array("1",$c)) {
    echo "checked";
  }

   ?>

  onclick="return false;"/>
                    </td>
                    <td>
                        <?php echo $odl; ?>
                    </td>

                    <td>
                        <?php echo $tecnicname; ?>
                    </td>

                    <td>

                        <a href="#edit<?php echo $id;?>" data-toggle="modal">
                            <button type='button' class='btn btn-warning btn-sm'><span class='glyphicon glyphicon-edit' aria-hidden='true'></span></button>
                        </a>
                  <!--      <a href="#delete<?php echo $id;?>" data-toggle="modal">
                            <button type='button' class='btn btn-danger btn-sm'><span class='glyphicon glyphicon-trash' aria-hidden='true'></span></button>
                        </a>
                      -->
                    </td>


                <!--
                  <div id="changepass" class="modal fade" role="dialog">
                        <div class="modal-dialog">

                            <div class="modal-content">
                                <form action="" method="post">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                        <h4 class="modal-title">Change Password</h4>
                                    </div>
                                    <div class="modal-body">
                                        <div class="form-group">
                                            <label class="control-label col-sm-2" for="name">Current:</label>
                                            <div class="col-sm-10">
                                                <input type="password" class="form-control" name="current_password" required placeholder="Current Password" autofocus autocomplete="off"> </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label col-sm-2" for="name">New:</label>
                                            <div class="col-sm-10">
                                                <input type="password" class="form-control" name="new_password" required placeholder="New Password" autocomplete="off"> </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label col-sm-2" for="name">Repeat:</label>
                                            <div class="col-sm-10">
                                                <input type="password" class="form-control" name="repeat_password" required placeholder="Repeat Password" autocomplete="off"> </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="submit" class="btn btn-primary" name="change_pass">Update</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>


                 -->


                    <!--Edit Item Modal -->
                    <div id="edit<?php echo $id; ?>" class="modal fade" role="dialog">
                        <form method="post" class="form-horizontal" role="form">
                            <div class="modal-dialog modal-lg">
                                <!-- Modal content-->
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                        <h4 class="modal-title">Modifica lavoro</h4>
                                    </div>
                                    <div class="modal-body">
                                                <input type="hidden" name="edit_item_id" value="<?php echo $id; ?>">
                                                <div class="form-group">
                                                    <label class="control-label col-sm-2" for="seriale">Seriale:</label>
                                                    <div class="col-sm-4">
                                                        <input type="text" class="form-control" id="seriale" name="seriale" value="<?php echo $serial; ?>" placeholder="Seriale"  readonly > </div>
                                                    <label class="control-label col-sm-2" for="mac">Seriale Reso:</label>
                                                    <div class="col-sm-4">
                                                        <input type="text"  class="form-control" id="mac" name="mac" value="<?php echo $macaddress; ?>" placeholder="Reso"  > </div>
                                                </div>
                                                <div class="form-group">
                                                  <label class="control-label col-sm-2" for="modello">Modello:</label>
                                                  <div class="col-sm-4">
                                                      <input type="text"  class="form-control" id="modello" name="modello" value="<?php echo $model; ?>" placeholder="Modello"  readonly> </div>
                                                      <label class="control-label col-sm-2" for="dingresso">Data Ingresso:</label>
                                                      <div class="col-sm-4">
                                                          <input type="datetime" class="form-control" id="dingresso" name="dingresso" value="<?php echo $entrydate; ?>" placeholder="Data Ingresso" readonly> </div>
                                                    <label class="control-label col-sm-2" for="du">Data Uscita:</label>
                                                    <div class="col-sm-4">
                                                        <input type="datetime" class="form-control" id="du" name="du" value="<?php echo $exitdate; ?>" placeholder="Data Uscita" readonly> </div>
                                                </div>

        										<div class="form-group">
                              <label class="control-label col-sm-2" for="installato">Installato:</label>
                              <div class="col-sm-4">
                                  <input type="checkbox" class="form-control" id="installato" name="installato" value="1"<?php if (in_array("1",$c)) { echo "checked"; } ?> > </div>

                                                    <label class="control-label col-sm-2" for="odl">ODL:</label>
                                                    <div class="col-sm-4">
                                                        <input type="text" class="form-control" id="odl" name="odl" value="<?php echo $odl; ?>" placeholder="ODL" > </div>
                                                </div>
        										<div class="form-group">
                              <label class="control-label col-sm-2" for="di">Data Installazione:</label>
                              <div class="col-sm-4">
                                  <input type="date" class="form-control" id="di" name="di" value="<?php echo $installationdate; ?>" placeholder="Data Installazione" > </div>

                                                    <label class="control-label col-sm-2" for="nome">Nome Tecnico:</label>
                                                    <div class="col-sm-2">
                                                        <input type="text" class="form-control" id="nome" name="nome" value="<?php echo $tecnicname; ?>" placeholder="Nome Tecnico"  readonly> </div>
                                                </div>


                                            </div>
                                    <div class="modal-footer">
                                        <button type="submit" class="btn btn-primary" name="update_item"><span class="glyphicon glyphicon-edit"></span> Modificare</button>
                                        <button type="button" class="btn btn-warning" data-dismiss="modal"><span class="glyphicon glyphicon-remove-circle"></span> Annulla</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                    <!--Delete Modal
                    <div id="delete<?php echo $id; ?>" class="modal fade" role="dialog">
                        <div class="modal-dialog">
                            <form method="post">

                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                        <h4 class="modal-title">Delete</h4>
                                    </div>
                                    <div class="modal-body">
                                        <input type="hidden" name="delete_id" value="<?php echo $id; ?>">
                                        <div class="alert alert-danger">Are you Sure you want Delete <strong>
                                                <?php echo $serial; ?>?</strong> </div>
                                        <div class="modal-footer">
                                            <button type="submit" name="delete" class="btn btn-danger"><span class="glyphicon glyphicon-trash"></span> YES</button>
                                            <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove-circle"></span> NO</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    -->
                </tr>
                <?php
                        }
                    /*    if(isset($_POST['change_pass'])){
                            $sql = "SELECT password FROM users WHERE username='$session_username'";
                            $result = $conn->query($sql);

                            if ($result->num_rows > 0) {
                                // output data of each row
                                while($row = $result->fetch_assoc()) {
                                    if($row['password'] != $current_password){
                                        echo "<script>window.alert('Invalid Password');</script>";
                                        $passwordErr = '<div class="alert alert-warning"><strong>Password!</strong> Invalid.</div>';
                                    } elseif($new_password != $repeat_password) {
                                        echo "<script>window.alert('Password Not Match!');</script>";
                                        $passwordErr = '<div class="alert alert-warning"><strong>Password!</strong> Not Match.</div>';
                                    } else{
                                        $sql = "UPDATE users SET password='$new_password' WHERE username='$session_username'";

                                        if ($conn->query($sql) === TRUE) {
                                            echo "<script>window.alert('Password Successfully Updated');</script>";
                                        } else {
                                            echo "Error updating record: " . $conn->error;
                                        }
                                    }
                                }
                            } else {
                                $usernameErr = '<div class="alert alert-danger"><strong>Username</strong> Not Found.</div>';
                                $username = "";
                            }
                        }

                      */
                        //Update Items
                        if(isset($_POST['update_item'])){
                          $edit_item_id = $_POST['edit_item_id'];
                            $mac = $_POST['mac'];
                          if(isset($_POST['installato'])) {
  	                     $installato=true;}
                         else{
                            $installato=false;
                         }
                          $odl = $_POST['odl'];
                          $di = $_POST['di'];
                            $sql = "UPDATE MATERIALETECNICIODBC SET
                                MACADDRESS='$mac',
                                installato='$installato',
                                ODL='$odl',
                                Datainstallazione='$di'
                                WHERE ID='$edit_item_id' ";
                            if ($conn->query($sql) === TRUE) {
                                echo '<script>window.location.href="inventory.php"</script>';
                            } else {
                                echo "Error updating record: " . $conn->error;
                            }
                        }

                        if(isset($_POST['delete'])){
                            // sql to delete a record
                            $delete_id = $_POST['delete_id'];
                            $sql = "DELETE FROM services WHERE id='$delete_id' ";
                            if ($conn->query($sql) === TRUE) {
                                $sql = "DELETE FROM services WHERE id='$delete_id' ";
                                if ($conn->query($sql) === TRUE) {
                                    $sql = "DELETE FROM services WHERE id='$delete_id' ";
                                    echo '<script>window.location.href="inventory.php"</script>';
                                } else {
                                    echo "Error deleting record: " . $conn->error;
                                }
                            } else {
                                echo "Error deleting record: " . $conn->error;
                            }
                        }
                    }

                    //Add Item
                    if(isset($_POST['add_job'])){
                        $seriale = $_POST['seriale'];
                        $mac = $_POST['mac'];
                        $modello = $_POST['modello'];
                        $dingresso=$_POST['dingresso'];
                        $du = $_POST['du'];
                        $servicef = $_POST['servicef'];
                        if(isset($_POST['tecnico'])) {
                       $tecnico="1";}
                       else{
                          $tecnico="0";
                       }
                        if(isset($_POST['installato'])) {
	                     $installato="1";}
                       else{
                          $installato="0";
                       }
                        $odl = $_POST['odl'];
                        $di = $_POST['di'];
                        $nome = $_POST['nome'];
                        $codice = $_POST['codice'];
                        $qta = $_POST['qta'];
                        $contatore = $_POST['contatore'];
                        $codice128 = $_POST['codice128'];
                        $sql = "INSERT INTO services (serial,macaddress,model,dataingreso,exitdate,service ,tecnic,installed,odl,installationdate,tecnicname,codice,qta,contatore,codice128)VALUES ('$seriale','$mac','$modello','$dingresso','$du','$servicef','$tecnico','$installato','$odl','$di','$nome','$codice','$qta','$contatore','$codice128')";
                        if ($conn->query($sql) === TRUE) {

                            echo '<script>window.location.href="inventory.php"</script>';
                        } else {
                            echo "Error: " . $sql . "<br>" . $conn->error;
                        }
                    }
?>
            </tbody>
        </table>
    </div>
  </div>
    <!--Add Item Modal
    <div id="add" class="modal fade" role="dialog">
        <div class="modal-dialog modal-lg">

            <div class="modal-content">
                <form method="post" class="form-horizontal" role="form">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title"></h4>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label class="control-label col-sm-2" for="seriale">Seriale:</label>
                            <div class="col-sm-4">
                                <input type="text" class="form-control" id="seriale" name="seriale" placeholder="Seriale" > </div>
                            <label class="control-label col-sm-2" for="mac">MAC:</label>
                            <div class="col-sm-4">
                                <input type="text" class="form-control" id="mac" name="mac" placeholder="MAC" > </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-sm-2" for="modello">Modello:</label>
                            <div class="col-sm-4">
                                <input type="text" class="form-control" id="modello" name="modello" placeholder="Modello" > </div>
                            <label class="control-label col-sm-2" for="dingresso">Data Ingresso:</label>
                            <div class="col-sm-4">
                                <input type="date" class="form-control" id="dingresso" name="dingresso" placeholder="Data Ingresso" > </div>
                                <label class="control-label col-sm-2" for="du">Data Uscita:</label>
                                <div class="col-sm-4">
                                    <input type="date" class="form-control" id="du" name="du" placeholder="Data" > </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-sm-2" for="servicef">Service Fortuna:</label>
                            <div class="col-sm-4">
                                <input type="text" class="form-control" id="servicef" name="servicef" placeholder="Service" > </div>
                            <label class="control-label col-sm-2" for="tecnico">Tecnico</label>
                            <div class="col-sm-1">
                                <input type="checkbox" class="form-control" id="tecnico" name="tecnico" placeholder="Tecnico" > </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-sm-2" for="installato">Installato</label>
                            <div class="col-sm-1">
                                <input type="checkbox" class="form-control" id="installato" name="installato" > </div>
                            <label class="control-label col-sm-5" for="odl">ODL:</label>
                            <div class="col-sm-4">
                                <input type="text" class="form-control" id="odl" name="odl" placeholder="ODL" > </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-sm-2" for="di">Data Installazione:</label>
                            <div class="col-sm-4">
                                <input type="date" class="form-control" id="di" name="di" > </div>
                            <label class="control-label col-sm-2" for="nome">Nome Tecnico:</label>
                            <div class="col-sm-4">
                                <input type="text" class="form-control" id="nome" name="nome" value="<?php echo $session_username; ?>" placeholder="Nome Tecnico"> </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-sm-2" for="codice">Codice:</label>
                            <div class="col-sm-4">
                                <input type="text" class="form-control" id="codice" name="codice" placeholder="Codice"> </div>
                                <label class="control-label col-sm-2" for="qta">QTA:</label>
                                <div class="col-sm-4">
                                    <input type="text" class="form-control" id="qta" name="qta" placeholder="QTA"> </div>


                        </div>
                        <div class="form-group">
                            <label class="control-label col-sm-2" for="contatore">Contatore:</label>
                            <div class="col-sm-4">
                                <input type="text" class="form-control" id="contatore" name="contatore" placeholder="Contatore"> </div>
                                <label class="control-label col-sm-2" for="codice128">Codice128:</label>
                                <div class="col-sm-4">
                                    <input type="text" class="form-control" id="codice128" name="codice128" placeholder="Codice128"> </div>


                        </div>

                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary" name="add_job"><span class="glyphicon glyphicon-plus"></span> Add</button>
                        <button type="button" class="btn btn-warning" data-dismiss="modal"><span class="glyphicon glyphicon-remove-circle"></span> Cancel</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    -->

    <!--Logout Modal -->
    <div id="logout" class="modal fade" role="dialog">
        <div class="modal-dialog modal-md">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Disconnettersi</h4>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="delete_id" value="<?php echo $id; ?>">
                    <div class="alert alert-danger">Sei sicuro di voler uscire
                        <strong>
                            <?php echo $_SESSION['username']; ?>?
                        </strong>
                    </div>
                    <div class="modal-footer">
                        <a href="logout.php">
                            <button type="button" class="btn btn-danger">SI </button>
                        </a>
                        <button type="button" class="btn btn-default" data-dismiss="modal">No</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>
