
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Test</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
   <script src="https://kit.fontawesome.com/a076d05399.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>


   <link href="lawyer.ico" rel="icon" type="image/x-icon" />



    <link href="Style.css" rel="stylesheet">
  <style>
    /* Set height of the grid so .sidenav can be 100% (adjust if needed) */

  </style>
  <script  type="text/javascript" >
	$(function () {
  $('[data-toggle="tooltip"]').tooltip()
});
  function closebtn() {
            document.getElementById("myClose").style.display = "none";
        }
	</script>
</head>
<body>

<div class="container-fluid">
  <div class="row content">
    <div class="col-sm-3 sidenav"  style="backgroundcolor: #e6e6ff">
    <a class="navbar-brand" href="#">
          <img src="avLogo.png" alt="">
        </a>

      <h4>Segreteria  Avvocati</h4><br/>
      <ul class="nav nav-pills nav-stacked " >
        <li class="active"> <a href="index.php"> <i class="fas fa-home "></i>  HOME</a></li>
        <li><a href="agpage.php"> <i class="fas fa-book" ></i>  AGENDA</a></li>
         <li  ><a href="avocati.php"> <i class="fas fa-user-tag"></i>  AVVOCATI</a></li>

      </ul><br>

    </div>



    <div class="col-sm-9">
   <!-- ///////////////////////      CORPO DELLA PAGINA              ////////////////////////////////////////////////////////////-->


     <div class="jumbotron jumbotron-fluid">
  <div class="container">
   <h1>Comunicazione da Cliente </h1>
  </div>
</div>





     <div class="container">

  <form id="contact-form" method="post" action="index.php" role="form">

    <div class="messages"></div>

    <div class="controls">

        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label for="form_name">Nome Cognome del Cliente *</label>
                    <input id="form_name" type="text" name="name" class="form-control"
                    placeholder="" required="required" data-error="Firstname is required.">
                    <div class="help-block with-errors"></div>
                </div>
            </div>
             <div class="col-md-6">
                <div class="form-group">
                    <label for="form_phone">Telefono*</label>
                    <input id="form_phone" type="tel" name="phone" class="form-control"
                    placeholder="" required="required" data-error="Telephone-Number is required.">
                    <div class="help-block with-errors"></div>
                </div>
            </div>

        </div>

        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                     <label for="email">Email del cliente </label>
                    <input id="email" type="email" name="email" class="form-control"
                     placeholder=""  data-error="Valid email is required.">
                    <div class="help-block with-errors"></div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                   <label for="referente">Avvocato di Riferimento</label>
						 <select class="selectpicker form-control"  name="selected"  required >
       						 <option value="" selected disabled hidden>Seleziona Avvocato </option>
        						<?php
							 include("connect.php");
							 $sql="select * from avvocati";
							 $result= mysqli_query($conn,$sql);
							 while($row=mysqli_fetch_array($result)){
								 echo '<option value="'.$row['nome'].'" >'.$row['nome'].'</option>';
							 }
							 ?>

                         </select>
                    <div class="help-block with-errors"></div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="form-group">
                    <label for="form_message">Messaggio*</label>
                    <textarea id="form_message" name="message" class="form-control"

                     rows="4" required data-error="Please,leave us a message."></textarea>
                    <div class="help-block with-errors"></div>
                </div>
            </div>
		</div>
           <div class="row">
               <div class="col-md-6">
               <div class="form-group" align="right">
               <label for="send"></label>
               <button type="submit" name="submit"  class="btn  btn-primary btn-lg btn-send"
               data-toggle="tooltip"  data-placement="bottom" title="Save and send mail" >
               <i class="fas fa-mail-bulk" style="color: #b3b3ff"></i>
                              SALVA
                 </button>
                  </div>
            </div>
            		<!-- INSERIMENTO SU DATABASE DEL NUOVO COMUNICAZIONE -->
<?php
if(isset($_POST["submit"])){
	include("connect.php");
	date_default_timezone_set("Europe/Rome");
	$date= date("Y-m-d H:i:s");
	$sql="INSERT INTO agenda (id,nome,tel,dat,email,note,avocato)
	VALUES
	('',
	'".$_POST['name']."',
	'".$_POST['phone']."',
	'$date',
	'".$_POST['email']."',
	'".$_POST['message']."',
	'".$_POST['selected']."'
	)";
	if($conn->query($sql)===TRUE ){
	 echo '<div  id="myClose"   class="alert" style="color:green; font-size:18px" >

	 				Inserito con sucesso!

	 			<span  class="closebtn" onclick="closebtn();">&times;</span>

	 	</div>

	 ';
	}
	else{
		echo '<div  id="myClose"   class="alert" style="color:green; font-size:18px" >

	  							Errore!

	 			<span  class="closebtn" onclick="closebtn();">&times;</span>

	 		</div>';
	}
	$conn->close();
}

?>


        </div>
           </div>
       </form>
</div>






</div>

<!--//////////////////////  FINE CORPO DELLA PAGINA HTML  /////////////////// -->


	</div>
	</div>

</body>
</html>
