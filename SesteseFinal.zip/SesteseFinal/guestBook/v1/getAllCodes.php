<?php

include  'Connections.php';
$sql ="SELECT *FROM visitatori ";

$r = mysqli_query($conn,$sql);
$result = array();
while($row = mysqli_fetch_array($r)){
 array_push($result,array(
	'code'=>$row['code']
	
    ));
}
echo json_encode(array('result'=>$result));
mysqli_close($conn);
	

?>