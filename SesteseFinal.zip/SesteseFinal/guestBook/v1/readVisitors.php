
<?php 
include  'Connections.php';
	if (isset($_POST['code'])) {
		$codeV = $_POST['code'];		
$sql = "SELECT  * FROM visitatori WHERE code ='$codeV' ";
$r = mysqli_query($conn,$sql);
$result = array();
while($row = mysqli_fetch_array($r)){
 array_push($result,array(
	 'id'=>$row['id'],
    'nome'=>$row['nome'],
	 'cognome'=>$row['cognome'],
	  'referente'=>$row['referente'],
	 'fornitore'=>$row['fornitore'],
	 'azienda'=>$row['azienda'],
	 'ruolo'=>$row['ruolo'],
	 'email'=>$row['email'] ,
	 
	 
	  'presente'=>$row['presente'],
	  'tipo'=>$row['tipo']
    ));
}
echo json_encode(array('result'=>$result));
mysqli_close($conn);
	}

if(isset($_POST['id'])){
	$id =$_POST['id'];
		date_default_timezone_set("Europe/Rome");
        $data = date('Y-m-d H:i:s');
	$sql1 = "UPDATE visitatori SET dataOraUscita='$data', presente='0' WHERE id='$id'";
	if($conn->query($sql1)==TRUE){	
	}
	
	
	$sql2="SELECT * FROM visitatori WHERE id='$id'";
	$r = mysqli_query($conn,$sql2);
$result = array();
while($row = mysqli_fetch_array($r)){
 array_push($result,array(
	'referente'=>$row['referente'],
	
    ));
	
}
	echo json_encode(array('result'=>$result));
mysqli_close($conn);
}


?>